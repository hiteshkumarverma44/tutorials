<?php

/**
 * @file
 * Contains \Drupal\custom_postal_code\Form\search.
 */

namespace Drupal\crud\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;


class search extends FormBase
{
  /**
   * {@inheritdoc}
   */

  public function getFormId()
  {
    return 'search_entry';
  }

  /**
   * {@inheritdoc}
   */

  public function buildForm(array $form, FormStateInterface $form_state)
  {

    $form['search_entry'] = array(
      '#type' => 'textfield',
      '#default_value' => '',
    );

    // $form['sort_name'] = array(
    //   '#type' => 'textfield',
    //   '#title' => 'Sort_name',
    //   '#default_value' => '',
    // );

    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('filter'),
      '#button_type' => 'primary',
    );

    // $form['sname'] = array(
    //   '#type' => 'submit',
    //   '#value' => $this->t('sort name'),
    //   '#button_type' => 'primary',
    //   '#attribtes' =>[
    //     'callback' => 'sort_name_handler()',
    //   ],
    // );
    // $url = \Drupal\Core\Url::fromRoute('crud.display_controller')->setrouteParameters('search_entry', 6876);
    // dpm($url);
    // $form_state->setRedirectUrl($url);
    return $form;
  }
// public function sort_name_handler(){
// echo ("test sorting");
// dpm('test sorting 2');
// }
  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    // if ($form_state->getValue('search_entry') == "") {
    //   $form_state->setErrorByName('from', $this->t('You must enter a valid Entry.'));
    // }
  }
  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    $field = $form_state->getValues();
    $search_entry = $field["search_entry"];
    // $sort_name = $field['sname'];
    // $url = \Drupal\Core\Url::fromRoute('crud.display_controller')
    // ->setRouteParameters(array('search_entry1' => $sort_name));
    $url = \Drupal\Core\Url::fromRoute('crud.display_controller')
      ->setRouteParameters(array('search_entry' => $search_entry));
    $form_state->setRedirectUrl($url);
  }
}
