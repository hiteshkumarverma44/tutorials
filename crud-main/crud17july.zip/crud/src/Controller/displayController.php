<?php

namespace Drupal\crud\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Kint\Kint;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
 * Class dispalyController.
 *
 * @package Drupal\mydata\Controller
 */
class displayController extends ControllerBase
{
    // public function getContent()
    // {
    //     // First we'll tell the user what's going on. This content can be found
    //     // in the twig template file: templates/description.html.twig.
    //     // @todo: Set up links to create nodes and point to devel module.
    //     $build = [
    //       'description' => [
    //         '#theme' => 'mydata_description',
    //         '#description' => 'foo',
    //         '#attributes' => [],
    //       ],
    //     ];
    //     return $build;
    // }

    public function search_controllers()
    {
        echo "test search form<br>";
        // $se_test = "search test";
        // dpm($se_test);
        // $test = \Drupal::request()->query->get('search_entry');
        // print($test);
        // $searchform = \Drupal::formBuilder()->getForm('Drupal\crud\Form\search');
        // return $searchform;
        // $database = \Drupal::database();
        // $query = $database->select('crud_code', 'n');
        // $query->fields('n', array('id', 'name', 'number', 'email', 'gender'));
        // $search_entry = \Drupal::request()->query->get('search_entry');
        // $output['form'] = $this->formBuilder()->getForm('\Drupal\crud\Form\search');
        // if ($search_entry != 'NULL' && !empty($search_entry)) {
        //     $query->condition('crud_code', $search_entry);
        // }

        // echo "<pre>";
        // print_r($output);
        // echo "</pre>";
        // return $output;
        // exit;

    }

    /**
     * Display.
     *
     * @return string
     *   Return Hello string.
     */
    public function display()
    {
        /**return [
          '#type' => 'markup',
          '#markup' => $this->t('Implement method: display with parameter(s): $name'),
        ];*/
        $this->search_controllers();
        $form['form'] = $this->formBuilder()->getForm('\Drupal\crud\Form\search');
        // $s_entry = \Drupal::request()->query->get('search_entry');
        $s_entry = \Drupal::request()->query->get('search_entry');
        dpm($s_entry);

        $query = \Drupal::database()->select('crud_code', 'm');
        $query->fields('m', ['id', 'name', 'number', 'email', 'gender']);
        if ($s_entry != 'NULL' && !empty($s_entry)) {
            // $query->condition('name', $s_entry);
            $orGroup = $query->orConditionGroup()
            ->condition('name', $s_entry)
            ->condition('number', $s_entry)
            ->condition('email', $s_entry)
            ->condition('gender', $s_entry)
            ->condition('id', $s_entry);
            $query->condition($orGroup);
            // $query->orderBy('name');
        }


        // $query->orderBy('name');

        $results = $query->execute()->fetchAll();


        // $s_conn = \Drupal::database();
        // $s_conn->select('crud_code','n');
        // $s_conn->fields('n',['name','number','email','gender']);
        // $s_result = $s_conn->execute()->fetchAll();
        // $return $output;


        $header_table = array(
            'id' => $this->t('SrNo'),
            'name' => $this->t('Name'),
            'number' => $this->t('MobileNumber'),
            'email' => $this->t('Email'),
            'gender' => $this->t('Gender'),
            'opt' => $this->t('operations'),
            'opt1' => $this->t('operations'),
        );

        //select records from table
        // $query = \Drupal::database()->select('crud_code', 'm');
        // $query->fields('m', ['id', 'name', 'number', 'email', 'gender']);
        // $results = $query->execute()->fetchAll();
        $rows = array();
        foreach ($results as $data) {
            $edit_link = Link::createFromRoute($this->t('Edit'), 'crud.mydata_form', ['id' => $data->id], ['absolute' => TRUE]);
            $delete_link = Link::createFromRoute($this->t('Delete'), 'crud.crud_delete', ['id' => $data->id], ['absolute' => TRUE]);
            $build_link_action = [
                'action_edit' => [
                    '#type' => 'html_tag',
                    '#value' => $edit_link->toString(),
                    '#tag' => 'div',
                    '#attributes' => ['class' => ['action-edit']]
                ],
                'action_delete' => [
                    '#type' => 'html_tag',
                    '#value' => $delete_link->toString(),
                    '#tag' => 'div',
                    // '#ajax' =>[  'callback' => 'cruddelete',],
                    '#attributes' => [
                        'class' => ['action-edit'],
                        // 'onclick' => 'cruddelete()'
                    ]
                ]
            ];

            //print the data from table
            $rows[] = array(
                'id' => $data->id,
                'name' => $data->name,
                'number' => $data->number,
                'email' => $data->email,
                'gender' => $data->gender,
                'opt' => \Drupal::service('renderer')->render($build_link_action['action_edit']),
                'opt1' => \Drupal::service('renderer')->render($build_link_action['action_delete']),


                // \Drupal::l('Delete', $delete),
                // \Drupal::l('Edit', $edit),
            );
        }
        //display data in site
        $form['table'] = [
            '#type' => 'table',
            '#header' => $header_table,
            '#rows' => $rows,
            '#empty' => $this->t('No users found'),
        ];
        return $form;
    }

    public function cruddelete()
    {
        $crud_del_test = "del test";
        dpm($crud_del_test);
        // Kint
        // exit;
        $id = \Drupal::routeMatch()->getParameter('id');
        $query = \Drupal::database();
        $query->delete('crud_code')
            ->condition('id', $id)
            ->execute();
        $messanger = \Drupal::messenger();
        $messanger->addStatus('your entry has been deleted');
        $response = new RedirectResponse("../display");
        $response->send();
        // $response = ;

        // $response->setRedirect('crud.display_controller');
    }

    public function crud_test()
    {
        echo "test test";
        exit;
    }
}
