<?php 
include_once ("function.php");

$data=new DB_con(); 
$id = $name = $price = $description = $category = $img = null;
$name_error = $price_error = $description_error = $category_error = $img_error = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["name"])) {
		$name_error = "Name is required";
	}else {
		$name = $_POST["name"];
	}


	if (empty($_POST['price'])) {
		$price_error = "Price is required";
	}else {
		$price = $_POST["price"];
	}

	if (empty($_POST['description'])) {
		$description_error = "Description is required";
	}else {
		$description =$_POST['description'];
	}

	if (empty($_POST['category'])) {
		$category_error = "Category is required";
	}else {
		$category =$_POST['category'];
	}

	if (empty($_FILES["img"]['name'])) {
		$img_error = "Image is required";
	}else {
		$img =$_FILES["img"]['name'];
	} 
}

if(isset($_POST['submit'])) {
	$name=$_POST['name'];
	$price=$_POST['price'];
	$description=$_POST['description'];
	$category = !empty($_POST['category']) ? $_POST['category'] : '';
	$img = $_FILES["img"]['name'];
	$id = $_POST['registration_id'];

 	if (move_uploaded_file($_FILES['img']['tmp_name'], __DIR__.'/image_product/'. $_FILES["img"]['name'])) {  
			$message = "File uploaded successfully!<br>";
		}else {  
			$message = "Sorry, file not uploaded, please try again!<br>";  
	}												

	if ($id == '') {
		if ($name !== '' && $price !== '' && $description !== ''  && $category !== ''  && $img !== '' ) {
 			$sql=$data->insert_product($name,$price,$description,$category,$img);
	  		if($sql) {
	    		echo "<div class='alert alert-success alert-dismissible'><h4>Data inserted</h4></div>";
	  		}else {
	    		echo "<div class='alert alert-danger alert-dismissible'><h4>Data not inserted</h4></div>";
	  		}
	  	}	
	}else {
		if ($name !== '' && $price !== '' && $description !== ''  && $category !== ''  && $img !== '' ) {
	  		$sql1=$data->update_product($id,$name,$price,$description,$category,$img);
	  		if($sql1) {
	  	  		echo "<div class='alert alert-success alert-dismissible'><h4>Data Updated</h4></div>";
	  		}else {
	    		echo "<div class='alert alert-danger alert-dismissible'><h4>Data Not Updated</h4></div>";
	  		}
  		}
	}
}


$fetch=$data->fetch_data($name);
$row = mysqli_num_rows($fetch);

if(isset($_GET['id']) &&  $_GET['id'] != '') {					
	$id = $_GET['id'];
	$sql1=$data->read_product($id,$name,$price,$description,$category,$img);
	$row = $sql1->fetch_assoc();
}

$img = '';
if(isset($row['img'])) {
	$img = $row['img'];
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Create Product</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript" src="js/form.js"></script>
</head>
<body>
	<div class="container">
		<div class="title">
			<label class="welcome-text">Create Product</label>
		</div>
		<div class="product">
			<button class="btn btn-default" id="view-c_btn" onclick="view_p()">View Products</button>
		</div>
		<div class="popup">
			<input type="hidden" name="">
		</div>
		<div class="background-c">
			<form method="post" class="p-form" id="p-form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data" autocomplete="off">
				<input type="hidden" id="registration_id" name="registration_id" value="<?php echo (isset($row['id']) && $row['id'] != '') ? $row['id'] : ''; ?>">
				<table class="table table-bordered">
					<tr>
						<td> <label>Name<span class="star">*</span></label> </td>
						<td> <input type="text" placeholder="" name="name" class="input-p" value="<?php echo (isset($row['name']) && $row['name'] != '') ? $row['name'] : ''; ?>" > <?php echo '<span class="valid">'.$name_error.'</span>'?></td>
					</tr>	
					<tr>
						<td> <label>Price<span class="star">*</span></label> </td>
						<td> <input type="text" name="price" class="input-p" value="<?php echo (isset($row['price']) && $row['price'] != '') ? $row['price'] : ''; ?>"><?php echo '<span class="valid">'.$price_error.'</span>'?></td>
					</tr>
					<tr>
						<td> <label>Description<span class="star">*</span></label> </td>
						<td> <textarea name="description" class="input-p"><?php echo (isset($row['description']) && $row['description'] != '') ? $row['description'] : ''; ?></textarea><?php echo '<span class="valid">'.$description_error.'</span>'?></td>
					</tr>
					<tr>
						<td> <label>Category<span class="star">*</span></label> </td>
						<td>
							<select class="input-p" name="category">
							<option value="" disabled selected>-- Select Category --</option>
								<?php 
										

									if( isset($_GET['id'])) {
								 		$select = $category == ''.$option_row['name'].'' ? 'selected="selected"' : '';}

									while ($option_row = mysqli_fetch_array($fetch)) {
										echo "<option ".$select." value='". $option_row['name'] ."'  >" .$option_row['name'] . " </option>" ;
									} 

								?>

							<option value="" disabled ></option>	
							</select>
							<?php echo '<span class="valid">'.$category_error.'</span>'?>
						</td>
					</tr>
					<tr>
						<td> <label>Image<span class="star">*</span></label> </td>
						<td> <input type="File" name="img" onchange="readURL(this);">
							 <img class="show-img" id ="show-img" src="image_product/<?php echo (isset($row) && $row['img'] != '') ? $img : ''; ?>" > <?php echo $img; ?><?php echo '<span class="valid">'.$img_error.'</span>'?>
						</td>
					</tr>
					<tr>
						<td> </td>
						<td> <input type="submit" name="submit" class="btn btn-primary" id="s-btn-primary" value="Create"> </td>
					</tr>	
				</table>
			</form>			
		</div>
	</div>
</body>
</html>
