<?php 
include("function.php");

$delete_data = new DB_con(); 

if(isset($_GET['id']) && !empty($_GET['id'])) {					
	$id = $_GET['id'];
	$del=$delete_data->delete_product($id);

	if ($del) {
		echo "<script>alert('Data Deleted');</script>";
	}else {
		echo "<script>alert('Data not Deleted');</script>"; 
	}

	header("location:view_product.php");
	exit();
}

if (isset($_POST['delId'])) {
		
	$delId = $_POST['delId'];
	// implode function break the array in to string 
	$delId = implode(',', $delId);
	$del=$delete_data->bulk_delete_product($delId);

	if ($del === true) {
		echo 1;
	}else {
		echo 0;
	}
}
?>