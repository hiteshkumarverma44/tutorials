<?php  
include_once ("function.php");

$getdata = new DB_con(); 
$username = $password = "";
$user_error = $password_error = "";

if (isset($_POST['submit'])) {
	$username = $_POST['username'];  
	$password = $_POST['password'];
	$sql = $getdata->login($username,$password);
	
	if ($username !== '' && $password !== '') {
		if ($sql) {  
			header("location:home.php");  
		}else {  
			echo "<div class='alert alert-danger alert-dismissible'><h4>Username / Password Not Match</h4></div>"; 
		}  
	}
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["username"])) {
		$user_error = "Username is required";
	}else {
		$username = $_POST["username"];
	}

	if (empty($_POST["password"])) {
		$password_error = "Password is required";
	}else {
		$password = $_POST["password"];
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript" src="js/form.js"></script>
</head>
<body>
	<div class="container">
		<div class="title">
			<label class="title-text">Login Form</label>
		</div>
		<div class="background-box">
			<form method="post" class="form" id="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
				<div class="row">
					<div class="col-sm-12">
						<label class="user-text">User Name<span class="star">*</span></label>
						<input type="text" name="username" class="input-box"> <?php echo '<span class="valid">'.$user_error.'</span>'?>			
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<label class="password-text">Password<span class="star">*</span></label>
						<input type="password" name="password" class="input-box"> <?php echo '<span class="valid">'.$password_error.'</span>'?>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">	
						<input type="submit" name="submit" value="Login" class="btn btn-primary" id="l-btn-primary">
					</div>
				</div>
			</form>	
		</div>	
	</div>
</body>
</html>