<?php
include_once ("function.php");

if(!($_SESSION)) {  
    header("Location:index.php");  
}  
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript" src="js/form.js"></script>
</head>
<body>
	<div class="container">
		<div class="title">
			<label class="welcome-text"> Welcome <?php echo $_SESSION['username']; ?></label>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<button class="btn btn-primary" id="h-btn-primary" onclick="category()">Create Category</button>			
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<button class="btn btn-primary" id="h-btn-primary" onclick="product()">Create Product</button>			
			</div>
		</div>
	</div>
</body>
</html>