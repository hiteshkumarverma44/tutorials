<?php 
session_start();
define('DB_SERVER','localhost');
define('DB_USER','harsh');
define('DB_PASS' ,'5HY0eRjZUlTMnJcw');
define('DB_NAME', 'harsh');
?>


