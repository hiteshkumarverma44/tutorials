<?php
include_once ("function.php");

$id = null;
$name = null;
$price = null;
$description = null;
$category = null;
$img = null;

$showdata=new DB_con();

if(isset($_GET['id']) &&  $_GET['id'] != '') {					
	$id = $_GET['id'];
	$sql=$showdata->read_product($id,$name,$price,$description,$category,$img);
	$row = $sql->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Read Product</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript" src="js/form.js"></script>
</head>
<body>
	<div class="container">
		<div class="title">
			<label class="welcome-text">Read Product</label>
		</div>
		<div class="background-c">
			<table class="table table-bordered">

				<?php
					$id =  (isset($row) && $row['id'] != '') ? $row['id'] : '';
					$name = (isset($row) && $row['name'] != '') ? $row['name'] : '';
					$price = (isset($row) && $row['price'] != '') ? $row['price'] : '';
					$description = (isset($row) && $row['description'] != '') ? $row['description'] : '';
					$category = (isset($row) && $row['category'] != '') ? $row['category'] : '';
					$img = (isset($row) && $row['img'] != '') ? $row['img'] : '';

					echo '<tr>';
					echo '<td>Id</td>';
					echo '<td>'.$id.'</td>';
					echo '</tr>';

					echo '<tr>';
					echo '<td>Name</td>';
					echo '<td>'.$name.'</td>';
					echo '</tr>';

					echo '<tr>';
					echo '<td>Price</td>';
					echo '<td>'.$price.'</td>';
					echo '</tr>';

					echo '<tr>';
					echo '<td>Description</td>';
					echo '<td>'.$description.'</td>';
					echo '</tr>';

					echo '<tr>';
					echo '<td>Category</td>';
					echo '<td>'.$category.'</td>';
					echo '</tr>';

					echo '<tr>';
					echo '<td>Image</td>';
					echo '<td><img class="show-img" src="image_product/'.$row['img'].'"></img>'.$img.'</td>';
					echo '</tr>';
				?>

			</table>
		</div>
	</div>
</body>
</html>