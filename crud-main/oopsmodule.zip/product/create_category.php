<?php 
include_once ("function.php");

$id = null;
$name = null;
$img = null;
$status = null;

$name_error = $img_error = $status_error = null;
$insertdata=new DB_con(); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if (empty($_POST["name"])) {
		$name_error = "Name is required";
	}else {
		$name = $_POST["name"];
	}

	if (empty($_FILES["img"]['name'])) {
		$img_error = "Image is required";
	}else {
		$img =$_FILES["img"]['name'];
	}

	if (empty($_POST["status"])) {
		$status_error = "Status is required";
	}else {
		$status = $_POST["status"];
	}
}

if(isset($_POST['submit'])) {
	$name=$_POST['name'];
	$img = $_FILES["img"]['name'];
	$status = !empty($_POST['status']) ? $_POST['status'] : '';
	$id = $_POST['registration_id'];

	if (move_uploaded_file($_FILES['img']['tmp_name'], __DIR__.'/image_category/'. $_FILES["img"]['name'])) {  
			$message = "File uploaded successfully!<br>";
		}else {  
			$message = "Sorry, file not uploaded, please try again!<br>";  
		}

	if ($id == '') {
		if ($name !== '' && $img !== '' && $status !== '' ) {
  			$sql=$insertdata->insert_category($name,$img,$status);
  			if($sql) {
	    		echo "<div class='alert alert-success alert-dismissible'><h4>Data inserted</h4></div>";
	  		}else {
	    		echo "<div class='alert alert-danger alert-dismissible'><h4>Data not inserted</h4></div>";
	  		}
  		}	
	}else {
		if ($name !== '' && $img !== '' && $status !== '' ) {
  			$sql1=$insertdata->update_category($id,$name,$img,$status);
  			if($sql1) {
  	  			echo "<div class='alert alert-success alert-dismissible'><h4>Data Updated</h4></div>";
  			}else {
    			echo "<div class='alert alert-danger alert-dismissible'><h4>Data Not Updated</h4></div>";
    		}
  	 	}		
	}
}

if(isset($_GET['id']) &&  $_GET['id'] != '') {					
	$id = $_GET['id'];
	$sql1=$insertdata->read_category($id,$name,$img,$status);
	$row = $sql1->fetch_assoc();
}

$status = '';

if(isset($row['status'])) {
	$status = $row['status'];
}

$img = '';
if(isset($row['img'])) {
	$img = $row['img'];
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Create Category</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript" src="js/form.js"></script>
</head>
<body>
	<div class="container">
		<div class="title">
			<label class="welcome-text">Create Category</label>
		</div>
		<div class="product">
			<button class="btn btn-default" id="view-c_btn" onclick="view_c()">View Category</button>
		</div>
		<div class="popup">
			<input type="hidden" name="" id="popup">
		</div>	
		<div class="background-c">		
			<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="c-form" id="c-form" enctype="multipart/form-data" autocomplete="off">
				<input type="hidden" id="registration_id" name="registration_id" value="<?php echo (isset($row['id']) && $row['id'] != '') ? $row['id'] : ''; ?>">
				<table class="table table-bordered">
					<tr>
						<td> <label>Name<span class="star">*</span></label> </td>
						<td> <input type="text" name="name" class="input-p" value="<?php echo (isset($row['name']) && $row['name'] != '') ? $row['name'] : ''; ?>"><?php echo '<span class="valid">'.$name_error.'</span>'?></td>
					</tr>	
					<tr>
						<td> <label>Image<span class="star">*</span></label> </td>
						<td> <input type="file" name="img" onchange="readURL(this);"> 
							<img class="show-img" id ="show-img" src="image_category/<?php echo (isset($row) && $row['img'] != '') ? $row['img'] : ''; ?>" /> <?php echo $img; ?> <?php echo '<span class="valid">'.$img_error.'</span>'?>
						</td>
					</tr>

					<tr>
						<td> <label>Status<span class="star">*</span></label> </td>
						<td> 
							<label for="yes">Yes</label>
							<input type="radio" id="yes" name="status" value="yes"  <?php echo ($status=='yes' ? 'checked' : '');?> class="yes"><br>
							<label for="no" class="no-text">No</label> 
							<input type="radio" id="no" name="status" value="no" <?php echo ($status=='no' ? 'checked' : '');?> class="no"><br>
							<?php echo '<span class="valid">'.$status_error.'</span>'?>
						</td>
					</tr>
					<tr>
						<td> </td>
						<td> <input type="submit" name="submit" class="btn btn-primary" id="s-btn-primary" value="Create"> </td>
					</tr>	
				</table>
			</form>			
		</div>
	</div>
</body>
</html>