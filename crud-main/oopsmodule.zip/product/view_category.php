<?php
include_once ("function.php");

$showdata=new DB_con();

$id = $name = $img = $status = $search = $start_from = $num_per_page = null;

$sql=$showdata->select_category($id,$name,$img,$status);

$sort = isset($_GET['order']) && $_GET['order'] == "asc" ? "desc" : "asc";

if( isset($_GET['order']) && $_GET['order'] == 'desc' ) {
	$order = 'asc';
}else if(  isset($_GET['order']) && $_GET['order'] == 'asc' ) {
	$order = 'desc';
} else if( !isset($_GET['order'])) {
	$order = 'asc';
}

if(!isset($_GET["orderby"])) {
	$orderBy = 'id';
}else if( isset($_GET['orderby']) && $_GET['orderby'] == 'id' ) {
	$orderBy = 'id';
}else if( isset($_GET['orderby']) && $_GET['orderby'] == 'name' ) {
	$orderBy = 'name';
}


$num_per_page=03;

	if(isset($_GET["page"])){
		$page=$_GET["page"];
	}else{
		$page=1;
	}

	$start_from=($page-1)*$num_per_page;
	$sql1=$showdata->sort_category($id,$name,$img,$status,$orderBy,$order,$start_from,$num_per_page);

$search= isset($_GET['search']) ? $_GET['search'] : ''  ;

if(isset($_GET['search-btn'])) {
	if ($_GET['search'] == '') {
		echo "<script> alert('Please Enter Value For Search'); </script>";
		echo "<script> window.open('view_category.php', '_self'); </script>";
	}else {
		$start=$per_page=null;
		$search=$_GET['search'];

		$per_page=3;

		if(isset($_GET["sp"])){
			$sp=$_GET["sp"];
		}else{
			$sp=1;
		}

		$start=($sp-1)*$per_page;
		$sql2=$showdata->search_category($id,$name,$img,$status,$search,$orderBy,$order,$start,$per_page);
		$sql3=$showdata->page_search_category($id,$name,$img,$status,$search);
	}
}	
?>

<!DOCTYPE html>
<html>
<head>
	<title>View Category</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript" src="js/form.js"></script>
</head>
<body>
	<div class="container">
		<div class="title">
			<label class="welcome-text">View Category</label>
		</div>
		<div class="product">
				<form method="get"  autocomplete="off" class="search">
					<input type="text" value="<?php  echo "$search" ; ?>" placeholder="Search By Id or Name.." name="search" class="input-s">
					<button name="search-btn" class="btn btn-default" id="search"><i class="fa fa-search"></i></button>
				</form>
				<button id="delete_btn" name="bulk_delete" class="btn btn-danger"><i class="fa fa-times"></i>Bulk Delete</button>
				<button class="btn btn-default" id="view_btn" onclick="category()">Create Category</button>
		</div>
		<div class="background-c">

			<table class="table table-bordered">
				
				<?php

					if(isset($_GET['search-btn'])) {
						echo '<tr>';
						echo '<th></th>';
						echo '<th> <a href="?search='.$search.'&search-btn=&orderby=id&order='.$sort.'"> ID</th>';
						echo '<th> <a href="?search='.$search.'&search-btn=&orderby=id&order='.$sort.'">Name</a> </th>';
						echo '<th>Image</th>';
						echo '<th>Status</th>';
						echo '<th>Action</th>';
						echo '</tr>';

						if (isset($sql2) && mysqli_num_rows($sql2) > 0 ) {
							while($row = mysqli_fetch_assoc($sql2)) {	
				 	 			echo '<tr>';
				 	 			echo '<td><input type="checkbox" name="checkBox[]" id="checkBox" value="'.$row['id'].'"></td>';
				 				echo '<td>'.$row['id'].'</td>';
								echo '<td>'.$row['name'].'</td>';
								echo '<td><img class="show-img" src="image_category/'.$row['img'].'" />'.$row['img'].'</td>';
								echo '<td>'.$row['status'].'</td>';
								echo '<td> 
								<a class="btn btn-primary" href="read_category.php?id='.$row['id'].'" target="_self"><i class="fa fa-list"></i>Read</a>
								<a class="btn btn-info" href="create_category.php?id='.$row['id'].'" target="_self"><i class="fa fa-edit"></i>Edit</a>
								<a class="btn btn-danger" href="delete_category.php?id='.$row['id'].'" target="_self" onclick="return confirmDelete()"><i class="fa fa-times"></i>Delete</a></td>';
								echo '</tr>';
							}
						}else {
							echo '<tr>';
							echo '<td colspan="8"> <div class="record"> <label>Record Not Found </label></div> </td>';
							echo '</tr>'; 
						}	
					}else {	
						echo '<tr>';
						echo '<th></th>';
						echo '<th> <a href="?orderby=id&order='.$sort.'"> ID</th>';
						echo '<th> <a href="?orderby=id&order='.$sort.'">Name</a> </th>';
						echo '<th>Image</th>';
						echo '<th>Status</th>';
						echo '<th>Action</th>';
						echo '</tr>';

						while($row = mysqli_fetch_assoc($sql1)) {	
			 	 			echo '<tr>';
			 	 			echo '<td><input type="checkbox" name="checkBox[]" id="checkBox" value="'.$row['id'].'"></td>';
			 				echo '<td>'.$row['id'].'</td>';
							echo '<td>'.$row['name'].'</td>';
							echo '<td><img class="show-img" src="image_category/'.$row['img'].'" />'.$row['img'].'</td>';
							echo '<td>'.$row['status'].'</td>';
							echo '<td> 
							<a class="btn btn-primary" href="read_category.php?id='.$row['id'].'" target="_self"><i class="fa fa-list"></i>Read</a>
							<a class="btn btn-info" href="create_category.php?id='.$row['id'].'" target="_self"><i class="fa fa-edit"></i>Edit</a>
							<a class="btn btn-danger" href="delete_category.php?id='.$row['id'].'" target="_self" onclick="return confirmDelete()"><i class="fa fa-times"></i>Delete</a></td>';
							echo '</tr>';	
						}	
					}	
				?>
			</table>
			
			<?php
				if(isset($_GET['search-btn'])) {

					$records=mysqli_num_rows($sql3);
				    $total=ceil($records/$per_page);
				    
				    for($j=1;$j<=$total;$j++) {
				        echo '<ul class="pagination">';
	  					echo '<li class="page-item"><a class="page-link" href="view_category.php?search='.$search.'&search-btn=&sp='.$j.'">'.$j.'</a></li>';
	 				 	echo '</ul>';
				    } 
				}else {
				    $total_records=mysqli_num_rows($sql);
				    $total_pages=ceil($total_records/$num_per_page);
				    
				    for($i=1;$i<=$total_pages;$i++) {
				        echo '<ul class="pagination">';
	  					echo '<li class="page-item"><a class="page-link" name="" href="view_category.php?page='.$i.'">'.$i.'</a></li>';
	 				 	echo '</ul>';
				    }
				}  
			?>

      	</div>
	</div>
</body>
</html>

    
