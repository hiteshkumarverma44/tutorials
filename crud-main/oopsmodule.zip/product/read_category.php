<?php
include_once ("function.php");

$id = null;
$name = null;
$img = null;
$status = null;

$showdata=new DB_con();

if(isset($_GET['id']) &&  $_GET['id'] != '') {					
	$id = $_GET['id'];
	$sql=$showdata->read_category($id,$name,$img,$status);
	$row = $sql->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Read Category</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript" src="js/form.js"></script>
</head>
<body>
	<div class="container">
		<div class="title">
			<label class="welcome-text">Read Category</label>
		</div>
		<div class="background-c">
			<table class="table table-bordered">

				<?php
					$id =  (isset($row) && $row['id'] != '') ? $row['id'] : '';
					$name = (isset($row) && $row['name'] != '') ? $row['name'] : '';
					$img = (isset($row) && $row['img'] != '') ? $row['img'] : '';
					$status = (isset($row) && $row['status'] != '') ? $row['status'] : '';

					echo '<tr>';
					echo '<td>Id</td>';
					echo '<td>'.$id.'</td>';
					echo '</tr>';

					echo '<tr>';
					echo '<td>Name</td>';
					echo '<td>'.$name.'</td>';
					echo '</tr>';

					echo '<tr>';
					echo '<td>Image</td>';
					echo '<td><img class="show-img" src="image_category/'.$row['img'].'"></img>'.$img.'</td>';
					echo '</tr>';

					echo '<tr>';
					echo '<td>Status</td>';
					echo '<td>'.$status.'</td>';
					echo '</tr>';
				?>
				
			</table>
		</div>
	</div>
</body>
</html>