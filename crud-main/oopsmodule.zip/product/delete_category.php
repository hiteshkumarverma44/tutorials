<?php 
include("function.php");

$delete_data = new DB_con(); 

if(isset($_GET['id']) && !empty($_GET['id'])) {					
	$id = $_GET['id'];
	$del=$delete_data->delete_category($id);

	if ($del) {
		echo "<script>alert('Data Deleted');</script>";
	}else {
		echo "<script>alert('Data not Deleted');</script>"; 
	}

	header("location:view_category.php");
	exit();
}


if (isset($_POST['deleteId'])) {	
	$deleteId = $_POST['deleteId'];
	// implode function break the array in to string 
	$deleteId = implode(',', $deleteId);
	$del=$delete_data->bulk_delete_category($deleteId);

	if ($del === true) {
		echo 1;
	}else {
		echo 0;
	}
}
?>