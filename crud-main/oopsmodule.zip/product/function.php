<?php
include "config.php";

class DB_con {
	function __construct() {
		$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
		$this->dbh=$con;
		// Check connection
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
	}

	public function login($username,$password) {
	    $ret=mysqli_query($this->dbh,"SELECT * FROM login WHERE username='$username' AND password='$password'");
	    $row = mysqli_fetch_array($ret);  
	    $no_rows = mysqli_num_rows($ret);  

		if ($no_rows == 1) {  
			$_SESSION['submit'] = true;  
			$_SESSION['username'] = $username; 
			return TRUE;  
		}else {
			return FALSE;  			
		}       
	}

	public function insert_product($name,$price,$description,$category,$img) {
		$ret=mysqli_query($this->dbh,"INSERT INTO product(name,price,description,category,img) VALUES('$name','$price','$description','$category','$img')");
		return $ret;	
	}

	public function insert_category($name,$img,$status)	{
		$ret=mysqli_query($this->dbh,"INSERT INTO category(name,img,status) VALUES('$name','$img','$status')");
		return $ret;
	}

	public function fetch_data($name) {
		$ret=mysqli_query($this->dbh,"SELECT name FROM category WHERE status='yes'");
		return $ret;	
	}

	public function select_category($id,$name,$img,$status) {
		$ret=mysqli_query($this->dbh,"SELECT * FROM category");
		return $ret;	
	}

	public function select_product($id,$name,$price,$description,$category,$img) {
		$ret=mysqli_query($this->dbh,"SELECT * FROM product");
		return $ret;	
	}

	public function sort_product($id,$name,$price,$description,$category,$img,$orderBy,$order,$start_from,$num_per_page) {
		$ret=mysqli_query($this->dbh,"SELECT * from product ORDER BY $orderBy $order limit $start_from,$num_per_page ");
		return $ret;	
	}

	public function sort_category($id,$name,$img,$status,$orderBy,$order,$start_from,$num_per_page) {
		$ret=mysqli_query($this->dbh,"SELECT * from category ORDER BY $orderBy $order limit $start_from,$num_per_page ");
		return $ret;	
	}

	public function read_category($id,$name,$img,$status) {
		$ret=mysqli_query($this->dbh,"SELECT * FROM category WHERE id=".$_GET['id']);
		return $ret;	
	}

	public function read_product($id,$name,$price,$description,$category,$img) {
		$ret=mysqli_query($this->dbh,"SELECT * FROM product WHERE id=".$_GET['id']);
		return $ret;	
	}

	public function search_product($id,$name,$price,$description,$category,$img,$search,$orderBy,$order,$start_from,$num_per_page) {
		$ret=mysqli_query($this->dbh,"SELECT * FROM product WHERE name LIKE '%$search%' || description LIKE '%$search%' ORDER BY $orderBy $order limit $start_from,$num_per_page ");
		return $ret;	
	}

	public function search_category($id,$name,$img,$status,$search,$orderBy,$order,$start,$per_page) {
		$ret=mysqli_query($this->dbh,"SELECT * FROM category WHERE id LIKE '%$search%' || name LIKE '%$search%' ORDER BY $orderBy $order limit $start,$per_page ");
		return $ret;
				
	}

	public function page_search_category($id,$name,$img,$status,$search) {
		$ret=mysqli_query($this->dbh,"SELECT * FROM category WHERE id LIKE '%$search%' || name LIKE '%$search%' ");
		return $ret;	
	}

	public function page_search_product($id,$name,$price,$description,$category,$img,$search) {
		$ret=mysqli_query($this->dbh,"SELECT * FROM product WHERE name LIKE '%$search%' || description LIKE '%$search%' ");
		return $ret;	
	}

	public function delete_category($id) {
  		$ret=mysqli_query($this->dbh,"DELETE FROM category WHERE id ='$id'");
  		return $ret;
  	}

  	public function delete_product($id) {
  		$ret=mysqli_query($this->dbh,"DELETE FROM product WHERE id ='$id'");
  		return $ret;
  	}

  	public function bulk_delete_category($deleteId) {
  		$ret=mysqli_query($this->dbh,"DELETE FROM category WHERE id IN($deleteId)");
  		return $ret;
  	}

  	public function bulk_delete_product($delId) {
  		$ret=mysqli_query($this->dbh,"DELETE FROM product WHERE id IN($delId)");
  		return $ret;
  	}

  	public function update_category($id,$name,$img,$status)	{
		$ret=mysqli_query($this->dbh,"UPDATE category SET name='$name',img='$img',status='$status' WHERE id = '$id' ");
		return $ret;
	}

	public function update_product($id,$name,$price,$description,$category,$img) {	
		$ret=mysqli_query($this->dbh,"UPDATE product SET name='$name',price='$price', description='$description', category='$category', img='$img' WHERE id = '$id' ");
		return $ret;
	}
} 
?>