$(document).ready(function(){
	/* validation with jquery plugin
  	$("#form").validate({
    	rules:
    		{
    			username: {	required:true },
    			password: {	required:true }	
    		},

    	messages:
    		{
    			username: { required:'User Name is Required' },
    			password: {	required:'Password is Required' }
    		}
	   }); 
  */

	$("#delete_btn").on('click',function() {
    var id=[];
		
    $(":checkbox:checked").each(function() {
			id.push($(this).val());
			element = this;
		});

		if (id.length > 0) {
      if (confirm("Are you sure want to delete this records")) {
        $.ajax({
          url : "delete_category.php",
          type: "POST",
          data:{deleteId:id},
          success:function(response) {
            if (response==1) {
              alert("Record delete successfully");
              window.location.href = "view_category.php";
            }else {
              alert("Some thing went wrong try again");
            }
          }
        });
      }
    }else {
      alert("Please select atleast one checkbox");
    }
  });

  $("#delete_pro").on('click',function() {
    var id=[];

    $(":checkbox:checked").each(function() {
    	id.push($(this).val());
    	element = this;
    });

    if (id.length > 0) {
      if (confirm("Are you sure want to delete this records")) {
        $.ajax({
          url : "delete_product.php",
          type: "POST",
          data:{delId:id},
          success:function(response) {
            if (response==1) {
              alert("Record delete successfully");
              window.location.href = "view_product.php";
            }else {
              alert("Some thing went wrong try again");
            }
          }
        });
      }
    }else {
      alert("Please select atleast one checkbox");
    }
  });
});

function category() {
	window.open('create_category.php', '_self');
}

function product() {
	window.open('create_product.php', '_self');
}

function view_p() {
	window.open('view_product.php', '_self');
}

function view_c() {
	window.open('view_category.php', '_self');
}

function confirmDelete() {
  return confirm('Are you sure want to Delete this record?'); 
}

function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function (e) {
      $('#show-img')
        .attr('src', e.target.result);
    };

    reader.readAsDataURL(input.files[0]);
  }
}
